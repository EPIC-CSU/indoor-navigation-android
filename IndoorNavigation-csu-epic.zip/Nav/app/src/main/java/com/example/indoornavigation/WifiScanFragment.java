package com.example.indoornavigation;


import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.net.wifi.ScanResult;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import com.example.indoornavigation.databinding.FragmentWifiscanfragmentBinding;

import java.util.Arrays;
import java.util.List;
import DeadReckoning.*;
import CNNprovider.*;

public class WifiScanFragment extends Fragment {

    private FragmentWifiscanfragmentBinding binding;
    double [] cor = {545.0, 700};
    double [] dr_cor = {545, 700};
    static double [] update=new double[2];
    private static final String TAG = "WIFISCAN_FRAGMENT";
    CNN fp;
    boolean wifi_scan_running = true;
    boolean dead_reckoning_running = true;
    boolean running = true;
    List<ScanResult> oldr=null;
    final Handler wifi_handler = new Handler();
    final Handler map_handler = new Handler();
    List<ScanResult> results;

    Bitmap mapBitmap;
    DeadReckoningProvider dr;
    CNN model;
    Handler updater=new Handler();
    Thread drt=new Thread(new Runnable() {
        @Override
        public void run() {
            dr = new DeadReckoningProvider(getContext(), 3.47f, 12, dr_cor);
            dr.startDeadReckoning();
            while(running){

                updater.post(new Runnable() {
                    @Override
                    public void run() {
                        dr_cor=dr.getXY();
                    }
                });
                try{
                    Log.d("corrd", Arrays.toString(dr_cor));
                    drt.sleep(200);
                }catch (InterruptedException e){
                    e.printStackTrace();
                }



            }
        }
    });


    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        binding = FragmentWifiscanfragmentBinding.inflate(inflater, container, false);

        //we need to look into step size i think its pixel equivelent.
        //dead reckoning is using step detector for now I will provide a better version later this semester the one I have is not stable
        //to get update from dead reckoning call dr.update() it will return double array with update {x,y}
        //for fingerprinting using cnn call fp.getprediction() with List<ScanResult> from wifiscan as a single parameter and it should return actual x, y coordinates.
        //DONT run deadreckoning without using it it will crash the app!
        //-Hamad
        /*
         *fp=new CNN(getContext());
         dr=new DeadReckoningProvider(getContext(),0.70f,5);
         *dr.startDeadReckoning();
        */
        drt.start();
        dead_reckoning_running=true;
        fp=new CNN(getContext());


        int TIME = 5000;
        if (wifi_scan_running) {
            wifi_handler.postDelayed(new Runnable() {
                public void run() {
                    callWifi();
                    wifi_handler.postDelayed(this, TIME);

                }
            }, TIME);
        }

        int TIME_MAP = 500;
        if (dead_reckoning_running) {
            map_handler.postDelayed(new Runnable() {
                public void run() {
                    cor = fusedcor(dr_cor);
                    CreateLayeredMap(cor);
                    map_handler.postDelayed(this, TIME_MAP);
                }
            }, TIME_MAP);
        }

        return binding.getRoot();
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // this allows for moving between fragments

        binding.buttonSecond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(WifiScanFragment.this)
                        .navigate(R.id.action_WifiScanFragment_to_FirstFragment);
            }
        });

    }

    public double[] fusedcor(double[] cor){
        boolean wifiscan=false;
        if (results!=oldr){
            wifiscan =true;
            oldr=results;
            double[] res=fp.getprediction(results);
            if(Math.abs(mag(res)-mag(dr_cor))<18){
                dr.feedback(res);
                return res;
            }
            else{
                return dr_cor;
            }

        }
        else{
            return dr_cor;}
        /*double[] deadrec= dr.getXY();
        int thresh=500;
        if(!wifiscan){
            if(Math.abs(mag(cor)-mag(deadrec))<thresh){                      //no wifi geting deadreckoning value if it less than 3m
                return deadrec;
            }
            else{
                return cor;
            }

        }
        else{
            double[] fingerp= fp.getprediction(results);
            double min=Double.min(mag(cor),mag(deadrec));                                //both present now we determine the best value aka min
            if(mag(deadrec)==min){
                if(Math.abs(mag(cor)-mag(deadrec))<thresh){                                    // lest than 3m i think we can adjust this value
                    return deadrec;
                }
                else{
                    return cor;
                }

            }

            else if(mag(fingerp)==min){
                if(Math.abs(mag(cor)-mag(fingerp))<thresh){
                    return fingerp;
                }
                else{
                    return cor;
                }


            }



        }


        return cor;*/
    }
    public double mag(double[] v){


        return  Math.sqrt(Math.pow(v[0],2)+Math.pow(v[1],2));
    }


    public Bitmap setMapImage(){
        assert getArguments() != null;
        String imgPath = getArguments().getString("mapImage");
        Log.i(TAG, imgPath);
        this.mapBitmap =  BitmapFactory.decodeFile(imgPath);
        this.mapBitmap = this.mapBitmap.copy(this.mapBitmap.getConfig(), true);
        return this.mapBitmap;
    }

//    public void loadMapImage(){
//        Bitmap mapImage = setMapImage();
//        binding.mapImage.setImageBitmap(mapImage);
//    }

    // this method is used to draw dots onto the map
    // with every iteration of the wifi signal button being pressed
    // the input to this method is the x and y coordinates generated from the database.
    public void CreateLayeredMap(double[] cor){
//        Bitmap bitmap= BitmapFactory.decodeResource(getActivity().getResources(),
//                                                    R.drawable.map);
//        Bitmap workingBitmap = Bitmap.createBitmap(bitmap);
//        Bitmap mutible = workingBitmap.copy(Bitmap.Config.ARGB_8888, true);
        float cor_x = (float) ((float) cor[0] * 2.75) - 25;
        float cor_y = (float) ((float) cor[1] * 2.75) - 20;

        Log.i(TAG, "Creating layered map");

        // load the image
//        Bitmap mapImageM = setMapImage(); // load fresh image

        String imgPath = getArguments().getString("mapImage");
        Log.i(TAG, imgPath);
        this.mapBitmap =  BitmapFactory.decodeFile(imgPath);
        this.mapBitmap = this.mapBitmap.copy(this.mapBitmap.getConfig(), true);
        //Bitmap bitmap= BitmapFactory.decodeResource(getActivity().getResources(),R.drawable.map);
        //Bitmap workingBitmap = Bitmap.createBitmap(bitmap);
       // Bitmap mutible = workingBitmap.copy(Bitmap.Config.ARGB_8888, true);
        Canvas canvas = new Canvas(this.mapBitmap);

        // create pain brushes
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setColor(Color.RED);
        paint.setStyle(Paint.Style.FILL_AND_STROKE);

        canvas.drawCircle(cor_x, cor_y, 30, paint);
        //canvas.drawBitmap(this.mapBitmap);
        if (running) {
            binding.mapImage.setImageBitmap(this.mapBitmap);
            binding.mapImage.invalidate();
        }

    }
    public List<ScanResult> callWifi(){
        WifiScan wifiScan = new WifiScan(getActivity().getApplicationContext());
        wifiScan.scanWiFi(getActivity().getApplicationContext());
        Log.i(TAG, String.valueOf(results));
        return this.results = wifiScan.getListResults();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        //dr.stopDeadReckoning();
        wifi_scan_running = false;
        dead_reckoning_running = false;
        dr.stopDeadReckoning();
        binding = null;
    }


}
