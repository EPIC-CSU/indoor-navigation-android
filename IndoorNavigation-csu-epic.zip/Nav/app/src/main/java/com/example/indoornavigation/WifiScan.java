package com.example.indoornavigation;

import android.Manifest;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.wifi.WifiManager;
import android.net.wifi.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.BroadcastReceiver;
import android.os.Build;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.util.Arrays;
import java.util.List;

public class WifiScan extends AppCompatActivity {

    //Variables declared below

    private WifiManager wifiManager;
    private static final String TAG = "WIFI_MANAGER_SCAN";
    private final int REQUEST_CODE_ASK_PERMISSIONS = 1;
    String []BSSID = new String[1000];
    String []LEVEL = new String[1000];
    String [][] ArrayToPass = new String[15][15];
    //added this value to return for the model making this module purpose just doing wifi scans --Hamad
    static List<ScanResult> results ;

    // This method is used to create the wifi manager. In essence ist is used to check if the wifi is enabled, if it is not then;
    // I will set the wifi to be enabled.
    // This method is to be called before scanning to avoid errors
    public WifiScan(Context context) {
        wifiManager = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (!wifiManager.isWifiEnabled()) {
            Toast.makeText(context, "WiFi is disabled ... We need to enable it", Toast.LENGTH_LONG).show();
            wifiManager.setWifiEnabled(true);
        }
    }

    public void scanWiFi(Context mainActivity){
        if (Build.VERSION.SDK_INT >= 23) {

            if (ActivityCompat.checkSelfPermission(mainActivity, Manifest.
                    permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission(mainActivity,
                    Manifest.permission.ACCESS_COARSE_LOCATION) !=
                    PackageManager.PERMISSION_GRANTED&& ActivityCompat.checkSelfPermission(mainActivity,
                    Manifest.permission.ACTIVITY_RECOGNITION) !=
                    PackageManager.PERMISSION_GRANTED) {

                requestPermissions(new String[]{
                                Manifest.permission.ACCESS_FINE_LOCATION},
                        REQUEST_CODE_ASK_PERMISSIONS);
                Log.i(TAG, "User location NOT ENABLED, waiting for permission");

            } else {
                mainActivity.registerReceiver(wifiReceiver, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
                ((WifiManager) mainActivity.getApplicationContext().getSystemService(WIFI_SERVICE)).startScan();
                //Toast.makeText(mainActivity, "Scanning WiFi ...", Toast.LENGTH_SHORT).show();
            }
        }
    }


        BroadcastReceiver wifiReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent)
            {
                //Toast.makeText(context, "Received Broadcast", Toast.LENGTH_SHORT).show();
                //Log.i(TAG, "received broadcast");
                results = wifiManager.getScanResults();   //removed declaration from here
                for (int i =0; i< results.size(); i++)
                {
                    BSSID[i] = results.get(i).BSSID;
                    LEVEL[i] = String.valueOf(results.get(i).level);
                }
                //Log.i(TAG, Arrays.toString(BSSID));
//                Log.i(TAG, Arrays.toString(LEVEL));
            }
        };

    public List<ScanResult> getListResults(){
        return this.results;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions, int[] grantResults) {
        if (requestCode == REQUEST_CODE_ASK_PERMISSIONS) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //start scanning
                ((WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE)).startScan();
            } else {
                // Permission for location Denied
                Toast.makeText(this, "Well cant help you then!",
                        Toast.LENGTH_SHORT)
                        .show();
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

}