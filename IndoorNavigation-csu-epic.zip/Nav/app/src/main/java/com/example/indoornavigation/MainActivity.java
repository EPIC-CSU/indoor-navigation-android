package com.example.indoornavigation;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableWrapper;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import com.example.indoornavigation.databinding.ActivityMainBinding;

import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.List;


@RequiresApi(api = Build.VERSION_CODES.Q)
public class  MainActivity extends AppCompatActivity {

    private static final int MY_PERMISSIONS_REQUEST_ACTIVITY_RECOGNITION = 2;
    private AppBarConfiguration appBarConfiguration;
    private static final String TAG = "MAIN_ACTIVITY";
    private final int REQUEST_CODE_ASK_PERMISSIONS = 1;
    public static final int MUTLIPLE_PERMISSIONS = 8;
    List<ScanResult> results;

    String[] PERMISSIONS = new String []{
            Manifest.permission.ACCESS_WIFI_STATE,
            Manifest.permission.CHANGE_WIFI_STATE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACTIVITY_RECOGNITION,
            Manifest.permission.INTERNET
    };

    @RequiresApi(api = Build.VERSION_CODES.Q)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        com.example.indoornavigation.databinding.ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.toolbar);
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        //setting the bitmap from the drawable folder
        Intent intent = getIntent();

        if (!hasPermissions(MainActivity.this, PERMISSIONS)) {

            ActivityCompat.requestPermissions(MainActivity.this, PERMISSIONS, MUTLIPLE_PERMISSIONS);
        }

        hasPermissions(MainActivity.this, PERMISSIONS);

//        if (Build.VERSION.SDK_INT >= 23) {
//
//            if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.
//                    permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
//                    && ActivityCompat.checkSelfPermission(MainActivity.this,
//                    Manifest.permission.ACCESS_COARSE_LOCATION) !=
//                    PackageManager.PERMISSION_GRANTED) {
//
//                requestPermissions(new String[]{
//                                Manifest.permission.ACCESS_FINE_LOCATION},
//                        REQUEST_CODE_ASK_PERMISSIONS);
//                Log.i(TAG, "User location NOT ENABLED, waiting for permission");
//
//            }
//            if(ActivityCompat.checkSelfPermission(this,
//                    Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_DENIED){
//                //ask for permission
//                requestPermissions(new String[]{Manifest.permission.ACTIVITY_RECOGNITION},REQUEST_CODE_ASK_PERMISSIONS);
//            }
//
//        }
    }
//    @Override
//    public void onRequestPermissionsResult(int requestCode,
//                                           String[] permissions, int[] grantResults) {
//        if (requestCode == REQUEST_CODE_ASK_PERMISSIONS) {
//            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                //start scanning
//                ((WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE)).startScan();
//            } else {
//                // Permission for location Denied
//                Toast.makeText(this, "Well cant help you then!",
//                        Toast.LENGTH_SHORT)
//                        .show();
//            }
//        } else {
//            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//        }
//    }

    public static boolean hasPermissions(Context context, String... permissions) {
        if (context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    Log.d(TAG, "PERMISSION_DENIED: " + permission);
                    return false;
                }
                else{
                    Log.d(TAG, "PERMISSION_GRANTED: " + permission);
                }
            }
        }
        return true;
    }

    public List<ScanResult> callWifi(){
        WifiScan wifiScan = new WifiScan(getApplicationContext());
        wifiScan.scanWiFi(getApplicationContext());
        Log.i(TAG, String.valueOf(results));
        return this.results = wifiScan.getListResults();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            startActivityForResult(new Intent(android.provider.Settings.ACTION_SETTINGS), 0);
            return true;
        }
        else if (id == R.id.WifiScan){
            Toast.makeText(this,"Wifi-Scan", Toast.LENGTH_SHORT).show();
            callWifi();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }



    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }
}
