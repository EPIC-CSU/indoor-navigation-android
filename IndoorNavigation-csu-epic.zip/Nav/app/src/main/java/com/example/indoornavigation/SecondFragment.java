package com.example.indoornavigation;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.net.wifi.ScanResult;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.provider.SyncStateContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.indoornavigation.databinding.FragmentSecondBinding;
import com.example.indoornavigation.databinding.FragmentWifiscanfragmentBinding;

import java.io.File;
import java.io.InputStream;
import java.net.URI;
import java.util.Arrays;
import java.util.List;

import CNNprovider.CNN;
import DeadReckoning.DeadReckoningProvider;

public class SecondFragment extends Fragment {

    private FragmentSecondBinding binding;
    private static final String TAG = "EXISTING MAP";
    private static final int WRITE_PERMISSION = 0x01;
    double [] cor = {545.0, 700};
    double [] dr_cor = {545, 700};
    static double [] update=new double[2];
    boolean wifi_scan_running = true;
    boolean dead_reckoning_running = true;
    boolean running = true;
    CNN fp;
    List<ScanResult> oldr=null;
    final Handler wifi_handler = new Handler();
    final Handler map_handler = new Handler();
    List<ScanResult> results;

    Bitmap mapBitmap;
    DeadReckoningProvider dr;
    CNN model;
    Handler updater=new Handler();
    Thread drt=new Thread(new Runnable() {
        @Override
        public void run() {
            dr = new DeadReckoningProvider(getContext(), 3.47f, 12, dr_cor);
            dr.startDeadReckoning();
            while(running){

                updater.post(new Runnable() {
                    @Override
                    public void run() {
                        dr_cor=dr.getXY();
                    }
                });
                try{
                    Log.d("corrd", Arrays.toString(dr_cor));
                    drt.sleep(200);
                }catch (InterruptedException e){
                    e.printStackTrace();
                }



            }
        }
    });

    public static final int RESULT_IMAGE = 3;
    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        binding = FragmentSecondBinding.inflate(inflater, container, false);
        requestWritePermission();
        drt.start();
        dead_reckoning_running=true;
        fp=new CNN(getContext());

        int TIME = 5000;
        wifi_handler.postDelayed(new Runnable() {
            public void run() {
                if (wifi_scan_running) {
                    callWifi();
                    wifi_handler.postDelayed(this, TIME);
                }
            }
        }, TIME);

        int TIME_MAP = 500;
        map_handler.postDelayed(new Runnable() {
            public void run() {
                if  (dead_reckoning_running) {
                    cor = fusedcor(dr_cor);
                    CreateLayeredMap(cor);
                    map_handler.postDelayed(this, TIME_MAP);
                }
            }
        }, TIME_MAP);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(SecondFragment.this).navigate(R.id.FirstFragment);
            }
        });

    }

    public double[] fusedcor(double[] cor){
        boolean wifiscan=false;
        if (results!=oldr){
            wifiscan =true;
            oldr=results;
            double[] res=fp.getprediction(results);
            if(Math.abs(mag(res)-mag(dr_cor))<18){
                dr.feedback(res);
                return res;
            }
            else{
                return dr_cor;
            }

        }
        else{
            return dr_cor;}
        /*double[] deadrec= dr.getXY();
        int thresh=500;
        if(!wifiscan){
            if(Math.abs(mag(cor)-mag(deadrec))<thresh){                      //no wifi geting deadreckoning value if it less than 3m
                return deadrec;
            }
            else{
                return cor;
            }

        }
        else{
            double[] fingerp= fp.getprediction(results);
            double min=Double.min(mag(cor),mag(deadrec));                                //both present now we determine the best value aka min
            if(mag(deadrec)==min){
                if(Math.abs(mag(cor)-mag(deadrec))<thresh){                                    // lest than 3m i think we can adjust this value
                    return deadrec;
                }
                else{
                    return cor;
                }

            }

            else if(mag(fingerp)==min){
                if(Math.abs(mag(cor)-mag(fingerp))<thresh){
                    return fingerp;
                }
                else{
                    return cor;
                }


            }



        }


        return cor;*/
    }
    public double mag(double[] v){


        return  Math.sqrt(Math.pow(v[0],2)+Math.pow(v[1],2));
    }


    public Bitmap setMapImage(){
        assert getArguments() != null;
        String imgPath = getArguments().getString("mapImage");
        Log.i(TAG, imgPath);
        this.mapBitmap =  BitmapFactory.decodeFile(imgPath);
        this.mapBitmap = this.mapBitmap.copy(this.mapBitmap.getConfig(), true);
        return this.mapBitmap;
    }

//    public void loadMapImage(){
//        Bitmap mapImage = setMapImage();
//        binding.mapImage.setImageBitmap(mapImage);
//    }

    // this method is used to draw dots onto the map
    // with every iteration of the wifi signal button being pressed
    // the input to this method is the x and y coordinates generated from the database.
    public void CreateLayeredMap(double[] cor){
//        Bitmap bitmap= BitmapFactory.decodeResource(getActivity().getResources(),
//                                                    R.drawable.map);
//        Bitmap workingBitmap = Bitmap.createBitmap(bitmap);
//        Bitmap mutible = workingBitmap.copy(Bitmap.Config.ARGB_8888, true);
        float cor_x = (float) ((float) cor[0] * 2.75) - 25;
        float cor_y = (float) ((float) cor[1] * 2.75) - 20;

        Log.i(TAG, "Creating layered map");

        // load the image
//        Bitmap mapImageM = setMapImage(); // load fresh image

//        String imgPath = getArguments().getString("mapImage");
//        Log.i(TAG, imgPath);
//        this.mapBitmap =  BitmapFactory.decodeFile(imgPath);
//        this.mapBitmap = this.mapBitmap.copy(this.mapBitmap.getConfig(), true);
        Bitmap bitmap= BitmapFactory.decodeResource(getActivity().getResources(),R.drawable.map);
        Bitmap workingBitmap = Bitmap.createBitmap(bitmap);
        Bitmap mutible = workingBitmap.copy(Bitmap.Config.ARGB_8888, true);
        Canvas canvas = new Canvas(mutible);

        // create pain brushes
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setColor(Color.RED);
        paint.setStyle(Paint.Style.FILL_AND_STROKE);

        canvas.drawCircle(cor_x, cor_y, 30, paint);
        //canvas.drawBitmap(this.mapBitmap);
        if (running) {
            binding.mapImage2.setImageBitmap(mutible);
            binding.mapImage2.invalidate();
        }


    }
    public List<ScanResult> callWifi(){
        WifiScan wifiScan = new WifiScan(getActivity().getApplicationContext());
        wifiScan.scanWiFi(getActivity().getApplicationContext());
        Log.i(TAG, String.valueOf(results));
        return this.results = wifiScan.getListResults();
    }



    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RESULT_IMAGE && resultCode == Activity.RESULT_OK && data != null){
            // this handles the getting the image data and putting the image path into
            // the variable named picturePath
            Uri selectedImage = data.getData();
            String[] filePathColumn = { MediaStore.Images.Media.DATA };
            Cursor cursor = getActivity().getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();


            // this handles sending the information via bundle to another fragment.
            Bundle bundle = new Bundle();
            bundle.putString("mapImage", picturePath);
            NavHostFragment.findNavController(SecondFragment.this).navigate(R.id.WifiScanFragment, bundle);

        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        if(requestCode == WRITE_PERMISSION){
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG, "Write Permission Failed");
            }
        }
    }

    private void requestWritePermission(){
        if(getActivity().checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(getActivity(),new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},WRITE_PERMISSION);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        wifi_scan_running = false;
        dead_reckoning_running = false;
        running = false;
        dr.stopDeadReckoning();
        binding = null;
    }

}
