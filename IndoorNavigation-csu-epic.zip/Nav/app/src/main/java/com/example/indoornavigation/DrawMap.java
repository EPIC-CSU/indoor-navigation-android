package com.example.indoornavigation;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.view.View;
import java.util.*;

/*
 * collision matrix:
 *      key: string (concatenated x and y coordinate)
 *      Value: boolean (true: valid space, false: invalid space)
 */

public class DrawMap extends View {

    Bitmap bitmap;

    //Dictionary using Hash table
    private Hashtable<String, Boolean> collision_matrix;

    public DrawMap(Context context) {
        super(context);
        bitmap= BitmapFactory.decodeResource(getResources(), R.drawable.map);
        createCollisions();
    }

    private void createCollisions() {
        // initialize hashtable
        collision_matrix = new Hashtable<String, Boolean>();

        // iterate through every pixel location
        for (int x = 0; x < bitmap.getWidth(); x++) {
            for (int y = 0; y < bitmap.getHeight(); y++) {

                // Get the color at each pixel location
                int color = bitmap.getPixel(x,y);
                // Make string key with both values
                String loc = String.valueOf(x) + String.valueOf(y);

                // 0xffffffff is white, if loc is valid set to true
                if (color == 0x00000000) {
                    collision_matrix.put(loc, false);
                } else {
                    collision_matrix.put(loc, true);
                }
            }
        }
    }

    private boolean checkSpace(int x, int y) {
        if (x > bitmap.getWidth() || y > bitmap.getHeight()) {
            return false; // Out of bounds...too large
        } else if (x < 0 || y < 0) {
            return false; // Out of bounds...too small
        } else {
            String key = String.valueOf(x) + String.valueOf(y);
            return collision_matrix.get(key);
        }
    }

    /*
     *  Old coordinate: (x1, y1)
     *  New Coordinate: (x2, y2)
     *  returns false if any point along the hypotenuse is invalid
     */
    public boolean checkLine(int x1, int y1, int x2, int y2) {
        // No movement = valid line
        if (x1 == x2 && y1 == y2) {
            return true;
        }

        // get distances and angle
        double xDist = x2 - x1;
        double yDist = y2 - y1;

        // divide by zero case
        if (xDist == 0) {
            if (yDist > 0) {
                for (int y = 0; y <= yDist; y++) {
                    int x = x1;
                    if (!checkSpace(x, y + y1))
                        return false;
                }
            } else {
                for (int y = 0; y >= yDist; y--) {
                    int x = x1;
                    if (!checkSpace(x, y + y1))
                        return false;
                }
            }
            return true;
        }

        // get angle ratio (arctan not needed cause we would just tan it later back to this ratio)
        double angle = yDist/xDist;

        /*
         * Split into 4 quadrants
         * 1. X distance is larger than y distance and x distance is positive
         * 2. X distance is larger than y distance and x distance is negative
         * 3. Y distance is larger than x distance and y distance is positive
         * 4. Y distance is larger than x distance and y distance is negative
         *
         */
        if (Math.abs(xDist) >= Math.abs(yDist)) {
            if (xDist > 0) {
                // Case 1
                for (int x = 0; x <= xDist; x++) {
                    int y = (int) (x * angle);
                    if (!checkSpace(x + x1, y + y1))
                        return false;
                }
            } else {
                // Case 2
                for (int x = 0; x >= xDist; x--) {
                    int y = (int) (x * Math.tan(angle));
                    if (!checkSpace(x + x1, y + y1))
                        return false;
                }
            }
        } else {
            if (yDist > 0) {
                // Case 3
                for (int y = 0; y <= yDist; y++) {
                    int x = (int) (y / angle);
                    if (!checkSpace(x + x1, y + y1))
                        return false;
                }
            } else {
                // Case 4
                for (int y = 0; y >= yDist; y--) {
                    int x = (int) (y / angle);
                    if (!checkSpace(x + x1, y + y1))
                        return false;
                }
            }
        }

        // all spaces valid so return true
        return true;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawBitmap( bitmap, 0, 0, null);
        super.onDraw(canvas);
    }
}