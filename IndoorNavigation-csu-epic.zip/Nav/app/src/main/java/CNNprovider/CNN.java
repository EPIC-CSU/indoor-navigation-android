package CNNprovider;

import android.content.Context;
import android.content.res.AssetManager;
import android.net.wifi.ScanResult;

import android.util.Log;
import android.util.Pair;



import com.example.indoornavigation.ml.CNN172m;

import org.tensorflow.lite.DataType;
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class CNN {
    private List<ScanResult> results;
    private ArrayList<Pair<String,Float>> sresult=new ArrayList<Pair<String,Float>>();
    private String[] bssidlist=new String[76];
    private String[] locationlist=new String[61];
    private float[] rssif=new float[209];
    private Context context;
    public CNN(Context context){
        this.context=context;

    }
    public double[] getprediction(List<ScanResult> results){
        double[] ret=new double[2];
        for (ScanResult scanResult : results) {
            sresult.add(new Pair<String,Float>(scanResult.BSSID,(float)((scanResult.level+100)/100.0)));

        }
        rssi();
        if(bssidlist[0]==null || locationlist[0]==null){
            try {
                bssidlist=filereader(context.getApplicationContext(),bssidlist.length,"BSSID.txt");
                locationlist=filereader(context.getApplicationContext(),locationlist.length,"Location.txt");
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        try {
            CNN172m model = CNN172m.newInstance(context);

            // Creates inputs for reference.
            TensorBuffer inputFeature0 = TensorBuffer.createFixedSize(new int[]{1, 209, 1}, DataType.FLOAT32);

            ByteBuffer byteBuffer = float2Byte(rssif);
            inputFeature0.loadBuffer(byteBuffer);

            // Runs model inference and gets result.
            CNN172m.Outputs outputs = model.process(inputFeature0);
            TensorBuffer outputFeature0 = outputs.getOutputFeature0AsTensorBuffer();

            String temp=locationlist[getLabel(outputFeature0.getFloatArray())];
            String[] cors={temp.substring(0,temp.indexOf(',')),temp.substring(temp.indexOf(",")+1)};
            ret=Arrays.stream(cors).mapToDouble(Double::parseDouble).toArray();
            Log.d("CNN: ", Arrays.toString(ret));
            // Releases model resources if no longer used.
            model.close();
            ret[0]=ret[0];
            ret[1]=ret[1];
            return ret;
        } catch (IOException e) {
            // TODO Handle the exception
        }

        return ret;
    }
    private static ByteBuffer float2Byte(float[] values) {
        ByteBuffer buffer = ByteBuffer.allocate(4 * values.length);

        for (float value : values){
            buffer.putFloat(value);
        }
        return buffer;
    }


    private void rssi(){
        Collections.sort(sresult, Comparator.comparing(p -> p.first));
        ArrayList<Float> r=new ArrayList<Float>();
        Arrays.fill(rssif, 0.0F);
        for(Pair<String,Float> s:sresult){
            for(int j=0;j<bssidlist.length;j++) {
                if (s.first.equals(bssidlist[j]))
                    rssif[j] = s.second;
            }
        }

    }
    private String[] filereader(Context context,int size,String filename) throws IOException {
        String[] ret=new String[size];
        AssetManager am = context.getAssets();
        InputStream is = am.open(filename);

        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        String line;

        for (int i =0;i< ret.length;i++){
            ret[i]=br.readLine();
        }
        br.close();

        return ret;
    }

    private static int getLabel(float[] out){
        int largest = 0;
        if ( out == null || out.length == 0 ) return 0;
        for ( int i = 1; i < out.length; i++ )
        {
            if ( out[i] > out[largest] ) largest = i;
        }
        return largest;
    }

}