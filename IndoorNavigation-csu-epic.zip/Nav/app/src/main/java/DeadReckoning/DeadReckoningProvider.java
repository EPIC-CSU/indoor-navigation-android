package DeadReckoning;
import android.content.Context;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

import android.provider.Telephony;
import android.util.Log;



import java.util.Arrays;


public class DeadReckoningProvider extends Thread implements SensorEventListener  {

    private final String TAG = "DeadReckoningProvider";

    // variables for compass rotation vector
    private float[] mMatrixR = new float[9];
    private float[] mMatrixValues = new float[3];


    // A map offset;
    // radians angle difference with respect to smartphone up and north
    private float northOffsetRadians;
    // movement per step
    // usually the number of pixels per step
    private int stepSize;
    // max bound point
    // if the map starts at 0, 0 then the other point describing the image rectangle
    private float[] acc=new float[3];
    private float[] mag=new float[3];
    // check if to update
    private SensorManager sensorManager;
    private Sensor stepDetector;
    // removed rotation vector and used accelerometer and magnetometer for filtering -Hamad
    private Sensor Accelerometer;
    private Sensor Magnometer;
    private boolean steptaken=false;
    static double[] update=new double[2];
    private Context context;
    static double[] cor=new double[2];

    /*
    actual value of this class, this is an array of size two.
    first element is only 0.0 or 1.0, indicating no step taken or step taken
    second element will describe the compass (azimuthal) angle
    */

    private double angle=0;




    public DeadReckoningProvider(Context context, float northOffsetRadians, int stepSize,double[] cor) {

        // set the initLocation and NorthOffset
        this.context=context;
        this.northOffsetRadians = northOffsetRadians;
        this.stepSize = stepSize;
        this.cor=cor;


        // init sensor manager
        sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        stepDetector = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
        Accelerometer=sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        Magnometer=sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

    }
    public void startDeadReckoning(){
        // try setting up all sensors required
        try {
            // make sure sensor manager is not null
            assert sensorManager != null;

            Log.d(TAG, "Setting up step detector");

            // init compass related sensor and register it


            // init step detector and register listener
            sensorManager.registerListener((SensorEventListener) this,
                    stepDetector,
                    SensorManager.SENSOR_DELAY_UI);
            sensorManager.registerListener((SensorEventListener) this,
                    Accelerometer,
                    SensorManager.SENSOR_DELAY_UI);
            sensorManager.registerListener((SensorEventListener) this,
                    Magnometer,
                    SensorManager.SENSOR_DELAY_UI);

            Log.d(TAG,"registration success!");
        } catch (Exception e) {
            Log.e("fail register listener", e.toString());
        }

    }
    public void stopDeadReckoning() {
        sensorManager.unregisterListener((SensorEventListener) this, stepDetector);
        sensorManager.unregisterListener((SensorEventListener) this, Accelerometer);
        sensorManager.unregisterListener((SensorEventListener) this, Magnometer);
    }
    public synchronized double[] getCor() {

        return update;
    }
    public synchronized double[] getXY(){


        return cor;
    }
    public synchronized void onSensorChanged(SensorEvent event) {

        switch (event.sensor.getType()) {
            /*
             * For the mAzimuth reading any change that less than 5 degrees will not update since
             * its not noticable.
             * -Hamad
             * */
            case Sensor.TYPE_STEP_DETECTOR:

                steptaken=true;

                break;

            case Sensor.TYPE_ACCELEROMETER:
                acc = lowPass(event.values.clone(), acc);
                break;
            case Sensor.TYPE_MAGNETIC_FIELD:
                mag = lowPass(event.values.clone(), mag);
                break;
        }

        sensorManager.getRotationMatrix(mMatrixR,null,acc,mag);
        sensorManager.getOrientation(mMatrixR,mMatrixValues);
        int mAzimuth = (int)Math.toDegrees( mMatrixValues[0]);

        if(Math.abs(Math.abs(mAzimuth)-Math.abs(angle))<5){}
        else{
            // set the azimuth values in values
            //this.stepsHeading[0] = 0;
            angle = mAzimuth;
        }
        updateCurrentLocation(update);



    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    private float[] lowPass( float[] input, float[] output ) {
        final float ALPHA = 0.1f;
        if ( output == null )
            return input;
        for ( int i=0; i<input.length; i++ )
        {
            output[i] = output[i] + ALPHA * (input[i] - output[i]);
        }
        return output;
    }


    public synchronized void feedback(double[] arr){
        this.cor[0]=arr[0];
        this.cor[1]=arr[1];

    }
    // given the current location
    private synchronized void updateCurrentLocation(double[] cor){
        // movement delta
        int dx;
        int dy;

        // get the step and angle values



        // dead reckoning provider should have it own XY coordinate
        // system and direction updates
        // update current angle with respect to relative north
        float angleRadian = -1 * ((float) Math.toRadians(angle) + this.northOffsetRadians);


        // calculate the dx and dy values that need to be added to curX and curY
        if(steptaken){
            dy = (int) (Math.cos(angleRadian) * this.stepSize) ;
            dx = (int) (Math.sin(angleRadian) * this.stepSize);
            this.cor[0]+=dx;
            this.cor[1]+=dy;
            update[0] =  dx;
            update[1] =  dy;
            steptaken=false;




        }
        else{
            update= new double[]{0, 0};

        }



    }




}